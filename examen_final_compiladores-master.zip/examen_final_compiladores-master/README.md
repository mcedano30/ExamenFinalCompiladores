# Examen final: Compiladores

Soy Carlos Polanco (19-0728)

### Mandato

Escribir un analizador para el fichero con la sintaxis dada más abajo. Este analizador deberá reconocer los siguientes Tokens:

Un Token para los valores de calificaciones y un Token para el literal de la calificación.
Los Tokens estarán separados por un tab.
 

Notas:

- Cada línea es una captura de calificación
- Hay un tope de 5 capturas.
- Las calificaciones serán valores entre 0 y 100.
- El valor de la calificación será un número real.
- Los literales de la calificación serán valores equivalentes a A, B, C. D y F.

 

Ejemplo Fichero:
```java
95.56      A
56.55      F
82.23      B
75.65      C
91.20      A
```
