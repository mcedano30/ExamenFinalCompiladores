package analizador;

public enum Tokens {
	Tab,
	Literal,
	Calificacion,
	Salto_Linea,
	ERROR
}
